# -*- coding: utf-8 -*-

# This sample demonstrates handling intents from an Alexa skill using the Alexa Skills Kit SDK for Python.
# Please visit https://alexa.design/cookbook for additional examples on implementing slots, dialog management,
# session persistence, api calls, and more.
# This sample is built using the handler classes approach in skill builder.
import random
import logging
import ask_sdk_core.utils as ask_utils

from ask_sdk_core.skill_builder import SkillBuilder
from ask_sdk_core.dispatch_components import AbstractRequestHandler
from ask_sdk_core.dispatch_components import AbstractExceptionHandler
from ask_sdk_core.handler_input import HandlerInput

from ask_sdk_model import Response

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

facts = [
		"Snakes can help predict earthquakes",
		"Pteronophobia is the fear of being tickled by feathers",
		"In Switzerland it is illegal to own just one guinea pig",
		"Banging your head against a wall for one hour burns 150 calories",
		"Crows can hold grudges against specific individual people",
		"So far, two diseases have successfully been eradicated: smallpox and rinderpest",
		"29th May is officially 'Put a Pillow on Your Fridge Day'",
		"Cherophobia is an irrational fear of fun or happiness",
		"7% of American adults believe that chocolate milk comes from brown cows",
		"If you lift a kangaroo’s tail off the ground it can’t hop",
		"Bananas are curved because they grow towards the sun",
		"Most Korean people don’t have armpit odor",
		"The original London Bridge is now in Arizona",
		"During your lifetime, you will produce enough saliva to fill two swimming pools",
		"If Pinocchio says 'My Nose Will Grow Now', it would cause a paradox",
		"Polar bears could eat as many as 86 penguins in a single sitting…",
		"Car manufacturer Volkswagen makes sausages",
		"Movie trailers were originally shown after the movie, which is why they were called 'trailers'",
		"An eagle can hunt down a young deer and fly away with it",
		"The smallest bone in your body is in your ear",
		"Tennis players are not allowed to swear when they are playing in Wimbledon",
		"Only 5% of the ocean has been explored",
		"The top six foods that make your fart are beans, corn, bell peppers, cauliflower, cabbage and milk",
		"There is a species of spider called the Hobo Spider",
		"A lion’s roar can be heard from 5 miles away",
		"Saint Lucia is the only country in the world named after a woman",
		"A baby spider is called a spiderling",
		"The United States Navy has started using Xbox controllers for their periscopes",
		"The following can be read forward and backwards: Do geese see God?",
		"A baby octopus is about the size of a flea when it is born",
		"A sheep, a duck and a rooster were the first passengers in a hot air balloon",
		"In Uganda, around 48% of the population is under 15 years of age",
		"The average male gets bored of a shopping trip after 26 minutes",
		"In the 16th Century, Turkish women could initiate a divorce if their husbands didn’t pour coffee for them",
		"Recycling one glass jar saves enough energy to watch television for 3 hours"
		]

# class LaunchRequestHandler(AbstractRequestHandler):
#     """Handler for Skill Launch."""
#     def can_handle(self, handler_input):
#         # type: (HandlerInput) -> bool

#         return ask_utils.is_request_type("LaunchRequest")(handler_input)

#     def handle(self, handler_input):
#         # type: (HandlerInput) -> Response
#         speak_output = "Welcome, you can say Hello or Help. Which would you like to try?"

#         return (
#             handler_input.response_builder
#                 .speak(speak_output)
#                 .ask(speak_output)
#                 .response
#         )


# class HelloWorldIntentHandler(AbstractRequestHandler):
#     """Handler for Hello World Intent."""
#     def can_handle(self, handler_input):
#         # type: (HandlerInput) -> bool
#         return ask_utils.is_intent_name("HelloWorldIntent")(handler_input)

#     def handle(self, handler_input):
#         # type: (HandlerInput) -> Response
#         speak_output = "Hello World!"

#         return (
#             handler_input.response_builder
#                 .speak(speak_output)
#                 # .ask("add a reprompt if you want to keep the session open for the user to respond")
#                 .response
#         )

class FactIntentHandler(AbstractRequestHandler):
    
    def can_handle(self, handler_input):
        return (ask_utils.is_request_type("LaunchRequest")(handler_input) or ask_utils.is_intent_name("FactIntent")(handler_input))

    def handle(self, handler_input):
        speak_output = random.choice(facts)

        return (
            handler_input.response_builder
                .speak(speak_output)
                .ask(speak_output)
                .response
        )

class HelpIntentHandler(AbstractRequestHandler):
    """Handler for Help Intent."""
    def can_handle(self, handler_input):
        # type: (HandlerInput) -> bool
        return ask_utils.is_intent_name("AMAZON.HelpIntent")(handler_input)

    def handle(self, handler_input):
        # type: (HandlerInput) -> Response
        speak_output = "You can say hello to me! How can I help?"

        return (
            handler_input.response_builder
                .speak(speak_output)
                .ask(speak_output)
                .response
        )


class CancelOrStopIntentHandler(AbstractRequestHandler):
    """Single handler for Cancel and Stop Intent."""
    def can_handle(self, handler_input):
        # type: (HandlerInput) -> bool
        return (ask_utils.is_intent_name("AMAZON.CancelIntent")(handler_input) or
                ask_utils.is_intent_name("AMAZON.StopIntent")(handler_input))

    def handle(self, handler_input):
        # type: (HandlerInput) -> Response
        speak_output = "Goodbye!"

        return (
            handler_input.response_builder
                .speak(speak_output)
                .response
        )


class SessionEndedRequestHandler(AbstractRequestHandler):
    """Handler for Session End."""
    def can_handle(self, handler_input):
        # type: (HandlerInput) -> bool
        return ask_utils.is_request_type("SessionEndedRequest")(handler_input)

    def handle(self, handler_input):
        # type: (HandlerInput) -> Response

        # Any cleanup logic goes here.

        return handler_input.response_builder.response


class IntentReflectorHandler(AbstractRequestHandler):
    """The intent reflector is used for interaction model testing and debugging.
    It will simply repeat the intent the user said. You can create custom handlers
    for your intents by defining them above, then also adding them to the request
    handler chain below.
    """
    def can_handle(self, handler_input):
        # type: (HandlerInput) -> bool
        return ask_utils.is_request_type("IntentRequest")(handler_input)

    def handle(self, handler_input):
        # type: (HandlerInput) -> Response
        intent_name = ask_utils.get_intent_name(handler_input)
        speak_output = "You just triggered " + intent_name + "."

        return (
            handler_input.response_builder
                .speak(speak_output)
                # .ask("add a reprompt if you want to keep the session open for the user to respond")
                .response
        )


class CatchAllExceptionHandler(AbstractExceptionHandler):
    """Generic error handling to capture any syntax or routing errors. If you receive an error
    stating the request handler chain is not found, you have not implemented a handler for
    the intent being invoked or included it in the skill builder below.
    """
    def can_handle(self, handler_input, exception):
        # type: (HandlerInput, Exception) -> bool
        return True

    def handle(self, handler_input, exception):
        # type: (HandlerInput, Exception) -> Response
        logger.error(exception, exc_info=True)

        speak_output = "Sorry, I had trouble doing what you asked. Please try again."

        return (
            handler_input.response_builder
                .speak(speak_output)
                .ask(speak_output)
                .response
        )

# The SkillBuilder object acts as the entry point for your skill, routing all request and response
# payloads to the handlers above. Make sure any new handlers or interceptors you've
# defined are included below. The order matters - they're processed top to bottom.


sb = SkillBuilder()

# sb.add_request_handler(LaunchRequestHandler())
# sb.add_request_handler(HelloWorldIntentHandler())
sb.add_request_handler(FactIntentHandler())
sb.add_request_handler(HelpIntentHandler())
sb.add_request_handler(CancelOrStopIntentHandler())
sb.add_request_handler(SessionEndedRequestHandler())
sb.add_request_handler(IntentReflectorHandler()) # make sure IntentReflectorHandler is last so it doesn't override your custom intent handlers

sb.add_exception_handler(CatchAllExceptionHandler())

lambda_handler = sb.lambda_handler()